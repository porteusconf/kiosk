  export LDFLAGS="-arch x86_64 -L/usr/local/lib -L. -L/usr/local/opt/qt@5/lib -L/usr/local/opt/zlib/lib " 

  export CPPFLAGS="-DHAVE_CONFIG_H  -Wno-write-strings -I/usr/local/opt/qt@5/include -I/opt/X11/include/libpng15 -arch x86_64  -I/usr/local/include  -I/usr/local/opt/zlib/include "

#  export LIBS=" -ljpeg  -lpng15 -ltiff  -lz -lX11 -libc++  -lc++  "
unset LIBS
#  export CAIRO_INCLUDE_DIRS="/usr/local/opt/cairo/include/cairo"
  unset  CAIRO_INCLUDE_DIRS


#For compilers to find jpeg you may need to set:
#  export LDFLAGS="-L/usr/local/opt/jpeg/lib"
#  export CPPFLAGS="-I/usr/local/opt/jpeg/include"

#For pkg-config to find jpeg you may need to set:
#  export PKG_CONFIG_PATH="/usr/local/opt/jpeg/lib/pkgconfig"
unset PKG_CONFIG
  export PKG_CONFIG_PATH="/usr/local/opt/qt@5/lib/pkgconfig"
printenv

#cmake  -DCMAKE_C_COMPILER=/usr//bin/gcc -DCMAKE_CXX_COMPILER=/usr/bin/g++ \
#cmake  -DCMAKE_C_COMPILER=/usr/local/bin/gcc-11 -DCMAKE_CXX_COMPILER=/usr/local/bin/g++-11 \
mkdir build
cd build
arch -x86_64 cmake --install-prefix=/usr/local/Cellar/gle/4.3.3  -DQt5_DIR=$(brew --prefix qt5)/lib/cmake/Qt5  -S ../src -B .
arch -x86_64 cmake --install-prefix=/usr/local/Cellar/gle/4.3.3  -DQt5_DIR=/usr/local/opt/qt@5/lib/cmake/Qt5  -S ../src -B .
make clean
# arch -x86_64 cmake  -B . --clean-first

