# About

GTKMan is a simple GTK+3 manual page viewer, written in Python. Manual
pages are viewed by specifying their name and optionally the section
they are in, just as with the original man command. The manual pages are
displayed in simple text form using the default system monospace font.

## Translation

GTKMan is available in many different languages. The translation project
is located at transifex.com and you can help with translating in your
language using the respective resource at the following URL:
https://www.transifex.com/gapan/salix/gtkman/
